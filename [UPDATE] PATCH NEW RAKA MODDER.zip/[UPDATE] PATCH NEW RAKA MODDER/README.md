## Important !

> DO WITH YOUR OWN RISK !! YOUR ACCOUNT MAY WILL BE BANNED !!\
> DO WITH YOUR OWN RISK !! YOUR ACCOUNT MAY WILL BE BANNED !!

## How to get auth token ?

* Download : [HTTP Cannary](https://apkcombo.com/id/httpcanary-http-sniffer-capture-analysis/com.guoshi.httpcanary)

1. Install HTTP Cannary or any Traffic Intercept apk to your phone
2. Intercept Stumble Guys ! Then play the game
3. Note :
* If u want to using Feature 1 . Play the game until you be a winner / Top 1
* If u want to using Feature 2 . Play the game until you in the Top 8
* If u want to using Feature 3 . Play the game until you in the Top 16
* If u want to using Feature 4 . Just play in the First Round ( Eliminated )
4. Open HTTP Canary and search :
* http://kitkabackend.eastus.cloudapp.azure.com:5010/round/finishv2/3 for Feature 1
* http://kitkabackend.eastus.cloudapp.azure.com:5010/round/finishv2/2 for Feature 2
* http://kitkabackend.eastus.cloudapp.azure.com:5010/round/finishv2/1 for Feature 3
* http://kitkabackend.eastus.cloudapp.azure.com:5010/round/finishv2/0 for Feature 4
5. Go to request tab and copy authorization value !
6. After running bot , close the game & dont relogin .. It will expire your token

## Video How to get auth token !
<a href="https://streamable.com/pa7o9f">
  <img src="https://i.ibb.co/Wvjz7XS/click-removebg-preview.png" width="250" height="96">
</a>

## Example Auth Token
```sh
{"DeviceId":"kontol","GoogleId":"kontol","FacebookId":"kontol","Token":"kontol","Timestamp":69696969,"Hash":"kontol"}
```

## How to use ?
<a href="https://user-images.githubusercontent.com/80010446/174403786-2dd1b2b5-01c3-49f2-8c72-db9259b96872.gif">
  <img src="https://user-images.githubusercontent.com/80010446/174403786-2dd1b2b5-01c3-49f2-8c72-db9259b96872.gif" width="95%">
</a>

## Proof
![ss](https://user-images.githubusercontent.com/80010446/174358039-1476fa06-ac8a-4c6a-bfa6-9ca8f3acafc2.png)
